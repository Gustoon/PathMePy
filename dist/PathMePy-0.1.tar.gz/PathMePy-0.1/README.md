# PathMePy
 A tool to add scripts to Path
