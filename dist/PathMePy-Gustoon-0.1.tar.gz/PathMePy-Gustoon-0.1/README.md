# PathMePy

A tool to add scripts to Path

## Installation
You just have to install the package using pip : `pip install PathMePy`

## usage
This packages add two function : 
`PathMePyDir(path)` and 
`PathMePyUserScriptFolder()` .
`PathMePyDir(path)` is for add to Path temporaly a direrctory and `PathMePyUserScriptFolder()` is for add the User Script folder to Path temporaly.